<!DOCTYPE html>
<html>
    <head>
        <title>PHP Day 1</title>
    </head>

    <body>
        <h1>Hello</h1>
        <?php
            echo 'My first PHP script!';
        ?> 
    </body>
</html>
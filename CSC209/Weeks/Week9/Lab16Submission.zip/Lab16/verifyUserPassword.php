
<?php
    function verifyUserPassword($username, $password) {
        $myJson = file_get_contents("./users.json");
        if(str_contains($myJson, $username) && str_contains($myJson, $password)){
            return true;
        }else{
            return false;
        }
    }
?>
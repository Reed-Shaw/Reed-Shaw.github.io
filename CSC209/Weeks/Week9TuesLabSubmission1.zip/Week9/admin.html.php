<!DOCTYPE html>
<html>
    <head>
        <title>Tuesday Lab Admin Page</title>
        <link rel="stylesheet" href="./CSS/basicCss.css">
    </head>
    <body>
        <div class="headerDiv">
            <a href="./week9.html">Back to Week 9</a>
        </div>
        <hr>
        <div class="mainDiv">
            <h1>Tuesday In-Class Lab 15 Pt 2</h1>
            <?php
                $myJson = file_get_contents("./users.json");
                $usernameArray = json_decode($myJson, true);
            ?>

            <?php
                function userTable($usernameArray){
                    echo "<table>";
                    echo "<tr><th>Username</th><th>Password</th><th>Logged Time</th></tr>";
                    foreach($usernameArray as $user){
                        echo "<tr>";
                        echo "<td>  " . $user["username"] . " </td>";
                        echo "<td>  " . $user["password"] . " </td>";
                        echo "<td>  " . $user["loggedtimes"] . " </td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                }

                userTable($usernameArray);
            ?>
        </div>
    </body>
</html>
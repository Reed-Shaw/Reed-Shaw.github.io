function displayPhotos($folderName) {
    $files = glob("./img/$folderName/*.jpeg");
    foreach ($files as $file):
    echo <img src="<?= $file ?>"><br>
}
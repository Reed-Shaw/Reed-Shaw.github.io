let myPoints;
let myEdges;
//let numOfPoints = getElementById("howManyPoints");
//Function that draws points
function drawCircle(ctx, numPts){
    myPoints = new Points(numPts);
    myPoints.drawC(ctx);
    drawEdges(ctx, myPoints);
}
//funciton that adds edges between each circle
function drawEdges(ctx, myPoints){
    myEdges = new Edges(myPoints);
    myEdges.drawEdges(ctx);
}

//function that clears all circles and edges
function clearGraph(){
    ctx.beginPath();
    ctx.clearRect(0, 0, WIDTH, HEIGHT);
}

//function that randomizes the points
//function randomizePoints(arrPoints){
    
//}

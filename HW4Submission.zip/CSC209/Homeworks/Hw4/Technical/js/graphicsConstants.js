//Styling points and canvas
const POINTSTYLE = "blue";
const POINTRADIUS = 10;
//const CANVASHEIGHT = "400px";
//const CANVASWIDTH = "600px";
const HEIGHT = 400;
const WIDTH = 600;
const EDGES = 0 ;
let NUMPTS = 2;
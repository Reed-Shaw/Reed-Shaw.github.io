let canvas;
let ctx;

function makeCanvas(){
    canvas = document.getElementById("pointsCanvas");
    ctx = canvas.getContext("2d");
    ctx.beginPath;
    ctx.strokeStyle = "blue";
    document.getElementById("pts").innerText += " " + NUMPTS;
    document.getElementById("edges").innerText += " " + EDGES;
}


